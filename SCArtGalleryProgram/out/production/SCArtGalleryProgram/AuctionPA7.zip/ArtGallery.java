import java.util.*;

public final class ArtGallery {

    private final List<Paintings> tempDalis = new LinkedList<>();
    private final List<Paintings> tempPicassos = new LinkedList<>();
    private final SortedMap<Paintings, Paintings> galleryPairs = new TreeMap<>();
    private final Paintings[] dalis;
    private final Paintings[] picassos;
    private int picassoIndex = -1;
    private int daliIndex = -1;

    ArtGallery(Collection<Paintings> allPaintings) {
        Objects.requireNonNull(allPaintings);

        allPaintings.forEach(paintings -> {
            Paintings.validate(paintings);

            if( paintings.artist().equals("Dali")) {
                tempDalis.add(paintings);
            } else if( paintings.artist().equals("Picasso")) {
                tempPicassos.add(paintings);
            } else {
                throw new IllegalStateException("Artist of painting must be Dali or Picasso.");
            }
        });
        Collections.sort(tempDalis);
        Collections.sort(tempPicassos);

        // Why convert from linked list to array -> Improves runtime and reduces complexity
        // Insertion into linked list O(1) but access O(n). Insertion into array O(n) but access O(1)
        dalis = tempDalis.toArray(new Paintings[0]);
        picassos = tempPicassos.toArray(new Paintings[0]);
    }

    public void createGalleryPairs() {

        do {

            daliIndex++;
            picassoIndex++;
            checkForPairs(picassoIndex, daliIndex);

        } while( picassoIndex < picassos.length - 1 && daliIndex < dalis.length );

    }

    private void checkForPairs(int pIndex, int dIndex) {

        if ( isPicassoShorter(pIndex, dIndex) ) {
            galleryPairs.put(dalis[dIndex], picassos[pIndex]);
        } else if ( isPicassoShorter(pIndex, dIndex + 1) ) {
            galleryPairs.put(dalis[dIndex+1], picassos[pIndex]);
            daliIndex++;
        } else if ( isPicassoShorter(pIndex + 1, dIndex) ) {
            galleryPairs.put(dalis[dIndex], picassos[pIndex+1]);
            picassoIndex++;
        }
    }

    private Boolean isPicassoShorter(int pIndex, int dIndex) {

        if( pIndex == picassos.length || dIndex == dalis.length) return false;

        return picassos[pIndex].height()
                .compareTo(
                        dalis[dIndex].height()
                ) < 0;
    }

    public SortedMap<Paintings, Paintings> getGalleryPairs() {

        return galleryPairs;
    }

    public String toString() {

        StringBuilder galleryString = new StringBuilder();

        for (Paintings painting : galleryPairs.keySet()) {
            galleryString.append("Dali of ").append(painting.toSimpleString())
                    .append(" and Picasso of ").append(galleryPairs.get(painting).toSimpleString())
                    .append("\n");
        }

        return galleryString.toString();
    }
}

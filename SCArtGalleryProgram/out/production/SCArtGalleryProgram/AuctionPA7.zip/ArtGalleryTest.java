import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

class ArtGalleryTest {

    private Paintings p1 = new Paintings(new BigDecimal(8), new BigDecimal(10), "Picasso");
    private Paintings p2 = new Paintings(new BigDecimal(5), new BigDecimal(20), "Picasso");
    private Paintings p3 = new Paintings(new BigDecimal(4), new BigDecimal(30), "Picasso");
    private Paintings p4 = new Paintings(new BigDecimal(7), new BigDecimal(40), "Picasso");
    private Paintings p5 = new Paintings(new BigDecimal(10), new BigDecimal(100), "Picasso");

    private Paintings d1 = new Paintings(new BigDecimal(7), new BigDecimal(10), "Dali");
    private Paintings d2 = new Paintings(new BigDecimal(8), new BigDecimal(20), "Dali");
    private Paintings d3 = new Paintings(new BigDecimal(4), new BigDecimal(25), "Dali");
    private Paintings d4 = new Paintings(new BigDecimal(7), new BigDecimal(30), "Dali");
    private Paintings d5 = new Paintings(new BigDecimal(2), new BigDecimal(100), "Dali");

    private List<Paintings> testPaintings = new ArrayList<>();
    private ArtGallery testGallery;



    @Test
    void createGalleryPairsTest() {
        testPaintings.add(p2);
        testPaintings.add(p3);
        testPaintings.add(p5);
        testPaintings.add(d2);
        testPaintings.add(d1);
        testPaintings.add(d5);
        testPaintings.add(p4);
        testPaintings.add(d3);
        testPaintings.add(p1);
        testPaintings.add(d4);

        testGallery = new ArtGallery(testPaintings);
        testGallery.createGalleryPairs();

        System.out.println(testGallery.toString());
    }

}
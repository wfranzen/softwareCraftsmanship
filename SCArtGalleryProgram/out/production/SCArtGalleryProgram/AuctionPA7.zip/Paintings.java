import java.math.BigDecimal;
import java.util.Objects;

public record Paintings(BigDecimal height, BigDecimal price, String artist) implements Comparable<Paintings> {


    public final Paintings validate() {
        Objects.requireNonNull(height());
        Objects.requireNonNull(price());
        Objects.requireNonNull(artist());
        return this;
    }

    public static final Paintings validate(Paintings painting) {

        Objects.requireNonNull(painting);
        return painting.validate();
    }

    @Override
    public int compareTo(Paintings o) {
        Objects.requireNonNull(o);

        // If the prices are equal, compare heights
        if (price().compareTo(o.price()) == 0) {
            return height().compareTo(o.height());
        } else {
            return price().compareTo(o.price());
        }
    }

    public String toSimpleString() {

        return "(Height: " + height() + ", Price: " + price() + ")";
    }

}


package edu.cwru.wcf13.gis;

import java.math.BigDecimal;

public record Coordinate(BigDecimal x, BigDecimal y) implements Comparable<Coordinate> {

    public static final Coordinate ORIGIN = new Coordinate(new BigDecimal("0"),new BigDecimal("0"));


    public final Coordinate validate() {

        try {
            if (this.x() == null || this.y() == null) {
                throw new NullPointerException("Problem.");
            }
        }
        catch(Exception e) {
            return null;
        }
        return new Coordinate(x, y);
    }

    public static final Coordinate validate(Coordinate coordinate) {

        try {
            if (coordinate == null) {
                // If coordinate is null, throw an NPE
                throw new NullPointerException("The coordinate object is a null value.");
            } else {
                // Otherwise, check to see if x or y are null
                if( coordinate.validate() == null) throw new NullPointerException();
                return coordinate;
            }
        }
        catch (NullPointerException n) {
            return null;
        }
    }


    public String toSimpleString() {

        return "The (x,y) of this coordinate is: (" + x.toString() + "," + y.toString() + ").";
    }


    @Override
    public int compareTo(Coordinate o) {

        int comparisonX = x.compareTo(o.x);
        int comparisonY = y.compareTo(o.x);

        if(comparisonX < 0 || (comparisonX == 0 && comparisonY < 0)) {

            return -1;
        } else if (comparisonX == 0 && comparisonY == 0) {

            return 0;
        } else {
            return 1;
        }

    }


}

package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Supplier;

public final class BiDimensionalMap<T> {

    //Initialize "points" to an empty treemap which will contain points of interest and their corresponding coordinates
    private final SortedMap<BigDecimal, SortedMap<BigDecimal, Collection<T>>> points = new TreeMap<>();

    public final Collection<T> get(BigDecimal x, BigDecimal y) {
        //Use the two given points as a key in the tree map and return the collection
        return points.get(x).get(y);
    }

    public final Collection<T> get(Coordinate coordinate) {
        //Use the coordinate as a key through the other get method and return the collection
        return get(coordinate.x(), coordinate.y());
    }


    //Instantiating the inner class
    private final BiDimensionalMap<T>.Updater updater = new Updater();

    public final class Updater {

        private BigDecimal x = new BigDecimal("0.0");
        public final Updater setX(BigDecimal x) {

            this.x = x;
            return updater;
        }
        private BigDecimal y = new BigDecimal("0.0");
        public final Updater setY(BigDecimal y) {

            this.y = y;
            return updater;
        }

        private Supplier<Collection<T>> collectionFactory = HashSet::new;
        public final Updater setCollectionFactory(Supplier<Collection<T>> collectionFactory) {

            this.collectionFactory = collectionFactory;
            return updater;
        }

        private Collection<T> values = collectionFactory.get();
        public final Updater setValues(Collection<T> values) {

            this.values = values;
            return updater;
        }

        public final Updater setCoordinate(Coordinate coordinate) {
            //Set the x and y values to those of a valid coordinate
            Coordinate validCoordinate = Coordinate.validate(coordinate);
            updater.x = validCoordinate.x();
            updater.y = validCoordinate.y();
            return updater;
        }


        public final Updater addValue(T value) {
            //Adds a single value to the Updater's values
            updater.values.add(value);
            return updater;
        }

        public final Collection<T> set() {

            Collection<T> oldMarkers = BiDimensionalMap.this.get(x, y);

            if( points.isEmpty() ) {

                points.put(x, new TreeMap<>());
                points.get(x).put(y, collectionFactory.get());
                Collection<T> newMarkers = values;
                points.get(x).get(y).clear();
                points.get(x).get(y).addAll(values);
                return null;
            }
            else if ( points.get(x).isEmpty() ) {

                points.get(x).put(y, collectionFactory.get());
                Collection<T> newMarkers = values;
                points.get(x).get(y).clear();
                points.get(x).get(y).addAll(values);
                return null;
            }

            return oldMarkers;
            //Return the previous collection at (x,y) or NULL if empty. Use validations to test?
                //If no interest points at x --> create a new treemap
                //If no interest points at (x,y) --> supply new collection w/ collectionFactory
        }

        public final boolean add() {

            //Add updater values to (x,y). Returns true if values changed from old ones
            if( points.get(x).containsValue(null) ) {
                points.put(x, new TreeMap<>());
                points.get(x).put(y, collectionFactory.get());
            }
            else if ( points.get(x).isEmpty() ) {
                points.get(x).put(y, collectionFactory.get());
            }
            return points.get(x).get(y).addAll(values);
                //If no interest points at x --> create a new treemap
                //If no interest points at (x,y) --> supply new collection w/ collectionFactory
        }
    }

    public final Updater getUpdater() {

        return new BiDimensionalMap<T>.Updater();
    }


}




// Old and long method I really didn't need to use, but I'm keeping just in case

//Collection<SortedMap<BigDecimal, Collection<T>>> mapCollection = points.values()
//Collection<T> finalTop = iterateTop(mapCollection, x);

/*
    public final Collection<T> iterateTop(Collection<SortedMap<BigDecimal, Collection<T>>> mapCollection, BigDecimal x) {
        // Iterates through the top SortedMap to return the collection at desired x
        Iterator<SortedMap<BigDecimal,Collection<T>>> iteratedTop = mapCollection.iterator();
        SortedMap<BigDecimal,Collection<T>> topPlaceholder;
        while( iteratedTop.hasNext() ) {

            if()
        }

    }
    */
package edu.cwru.wcf13.gis;

public record InterestPoint<M>(Coordinate coordinate, M marker) {

    public final InterestPoint validate() {

        //Validate the coordinate and throw a NPE if marker is null
        try {
            if( Coordinate.validate(coordinate) == null) throw new NullPointerException();
            if(marker == null) throw new NullPointerException();
            return this;
        }
        catch(NullPointerException n) {
            return null;
        }
    }

    public static final InterestPoint validate(InterestPoint interestPoint) {

        //NullPointerException if interest point or coordinate null
        try {
            if(interestPoint == null) throw new NullPointerException();
            if(interestPoint.validate() == null) throw new NullPointerException();
            return interestPoint;
        }
        catch(NullPointerException n) {
            return null;
        }
    }

    public boolean hasMarker(M marker) {

        //return boolean if coordinate has marker equal to argument
        return this.marker.equals(marker);
    }

    public String toString() {

        //Return compact and informative string of POI
        return "INFORMATIVE STRING REPRESENTATION OF INTEREST POINT";
    }
}

package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.Objects;

public record InterestPoint<M>(Coordinate coordinate, M marker) {

    public final InterestPoint<M> validate() {

        Objects.requireNonNull(marker());
        Coordinate.validate(coordinate());
        return this;
    }

    public static final InterestPoint validate(InterestPoint interestPoint) {

        Objects.requireNonNull(interestPoint);
        return interestPoint.validate();
    }

    public boolean hasMarker(M marker) {

        Objects.requireNonNull(marker());
        return marker().equals(marker);
    }

    public String toString() {

        //Return compact and informative string of POI
        return ("Interest Point at " + coordinate().toSimpleString() +  " has the marker: " + marker().toString());
    }

    public final BigDecimal x() {

        return InterestPoint
                .validate(this)
                .coordinate()
                .x();
    }

    public final BigDecimal y() {

        return InterestPoint
                .validate(this)
                .coordinate()
                .y();
    }


}

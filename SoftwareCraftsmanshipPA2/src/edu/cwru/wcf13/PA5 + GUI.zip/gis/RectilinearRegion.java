package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class RectilinearRegion {

    private final Set<Rectangle> rectangles;

    private RectilinearRegion(Set<Rectangle> rectangles) {

        Objects.requireNonNull(rectangles);

        this.rectangles = rectangles.stream()
                .map( rectangle -> Rectangle.validate(rectangle))
                .collect(Collectors.toSet());

    }

    public final Set<Rectangle> getRectangles() {

        return this.rectangles; //Return a copy
    }

    private final BiDimensionalMap<Rectangle> rectangleMap() {

        /*
        * Calls on a helper method, passing in a function to be used in Rectangle.java to get a rectangle's X/Y bounds
        * Creates a set of all the values between the bounds left/bottom inclusive, right/top exclusive
        * All the separate rectangles bounds are then concatenated into what is xCoord and yCoord. Set deletes duplicates.
        * Allows for rectangles to be touching directly on any side or corner
        */

        BiDimensionalMap<Rectangle> grid = new BiDimensionalMap<>( coordSet(Rectangle::left, Rectangle::right), coordSet(Rectangle::bottom, Rectangle::top));
        BiDimensionalMap<Rectangle>.Updater gridUpdater = grid.getUpdater();

        for (Rectangle rect : getRectangles()) { //O( n^3 ) is absolute garbage

            BiDimensionalMap<Rectangle> tempGrid = grid.slice(rect);
            tempGrid.addEverywhere(rect);

            fillRectMap(gridUpdater, rect, tempGrid);

        }
        return grid;
    }

    public boolean isOverlapping() {

        boolean overlapping = false;

        for(Coordinate coord : rectangleMap().coordinateSet()) {

            if( rectangleMap().get(coord).size() > 1 ) {
                overlapping = true;
            }
        }
        return overlapping;
    }

    public static final RectilinearRegion of(Set<Rectangle> rectangles) {


        Objects.requireNonNull(rectangles);
        rectangles.forEach(rect -> Rectangle.validate(rect));


        RectilinearRegion newRegion = new RectilinearRegion(rectangles);
        if ( newRegion.isOverlapping() )  {
            throw new IllegalArgumentException("The given rectilinear region is overlapping.");

        }

        return newRegion;
    }


    // Helper and Auxiliary Methods ******************************************************************


    // Getter method for the rectangle map
    BiDimensionalMap<Rectangle> getRectMap() {

        return rectangleMap();
    }

    // Method for creating the xCoord and yCoord sets used in rectangleMap
    Set<BigDecimal> coordSet(Function<Rectangle, BigDecimal> lower, Function<Rectangle, BigDecimal>  upper) {

        return getRectangles().stream()
                .flatMap(rect -> rect.rectBounds(lower.apply(rect), upper.apply(rect)).stream())
                .collect(Collectors.toSet());
    }

    // Fills the grid in rectangleMap with values. Still kind of ugly, clean up for PG5
    void fillRectMap(BiDimensionalMap<Rectangle>.Updater gridUpdater, Rectangle currentRect, BiDimensionalMap<Rectangle> tempGrid) {

        for(BigDecimal x : currentRect.rectBounds(currentRect.left(), currentRect.right())) { // Turn into a helper method
            for(BigDecimal y : currentRect.rectBounds(currentRect.bottom(), currentRect.top())) {

                gridUpdater.setCoordinate(new Coordinate(x, y));
                gridUpdater.setValues( tempGrid.get(x,y));
                gridUpdater.add();

            }
        }
    }

}

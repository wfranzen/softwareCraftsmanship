package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class InterestPoints<M> {

    private final BiDimensionalMap<InterestPoint> points;

    private InterestPoints(Builder builder) {

        this.points = builder.points;
    }

    public final Collection<InterestPoint> get(Coordinate coordinate) {

        Coordinate.validate(coordinate);
        return points.get(coordinate);
    }

    public final List<Collection<InterestPoint>> interestPoints() {

        return points.coordinateSet().stream()
                .map( points::get )
                .toList();
    }

    public final String toString() {
        // Delegates the toString method to BiDimensionalMap
        return points.toString();
    }

    public final long count(RectilinearRegion region, M marker) {

        Objects.requireNonNull(marker);
        Objects.requireNonNull(region);


        return region
                .getRectMap()
                .collectionSize(
                        Predicate.isEqual(marker)
                );

        // Use the marker as a predicate and check the values of region against interestPoints ?
        /*return points.collectionSize(
                Predicate.isEqual(region.getRectMap().collectionList().stream()
                        .map(HashSet::new)
                        .collect(Collectors.toSet())));*/

    }


    public static class Builder {

        private final BiDimensionalMap<InterestPoint> points = new BiDimensionalMap<>(new HashSet<>(), new HashSet<>());

        public final boolean add(InterestPoint interestPoint) {

            InterestPoint.validate(interestPoint);
            return points
                    .getUpdater()
                    .setCoordinate(interestPoint.coordinate())
                    .addValue(interestPoint)
                    .add();
        }

        public final InterestPoints build() {

            return new InterestPoints(this);
        }

    } // End of Builder()

} // End of InterestPoints()

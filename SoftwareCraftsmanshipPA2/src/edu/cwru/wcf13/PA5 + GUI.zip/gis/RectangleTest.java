package edu.cwru.wcf13.gis;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class RectangleTest {

    private final Coordinate coordTest = new Coordinate(new BigDecimal("1"), BigDecimal.ZERO);
    private final Coordinate coordTest2 = new Coordinate(new BigDecimal("3"), new BigDecimal("2"));
    private final Coordinate nullCoord = new Coordinate(null, BigDecimal.TEN);

    private final Rectangle testRect = new Rectangle(coordTest, coordTest2);
    private final Rectangle nullRect = new Rectangle(coordTest, nullCoord);

    @Test
    void validate() {

        assertEquals(testRect, testRect);
        assertThrows(NullPointerException.class, () -> {
            nullRect.validate();
        });
    }

    @Test
    void testValidate() {

        assertEquals(testRect, Rectangle.validate(testRect));
        assertThrows(NullPointerException.class, () -> {
            Rectangle.validate(nullRect);
        });
    }

    @Test
    void left() {

        assertEquals(new BigDecimal("1"), testRect.left());

//        assertThrows(NullPointerException.class, () -> {
//            nullRect.left();
//        });
    }

    @Test
    void right() {

        assertEquals(new BigDecimal("3"), testRect.right());
    }

    @Test
    void bottom() {

        assertEquals(new BigDecimal("0"), testRect.bottom());
    }

    @Test
    void top() {

        assertEquals(new BigDecimal("2"), testRect.top());
    }

    @Test
    void bottomLeft() {
    }

    @Test
    void topRight() {
    }

    @Test
    void testXValues() {


    }

    @Test
    void testBounds() {


    }
}
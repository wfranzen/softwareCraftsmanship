package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.Objects;

public record Coordinate(BigDecimal x, BigDecimal y) implements Comparable<Coordinate> {

    public static final Coordinate ORIGIN = new Coordinate(BigDecimal.ZERO, BigDecimal.ZERO);

    public final Coordinate validate() {
        Objects.requireNonNull(x());
        Objects.requireNonNull(y());
        return this;
    }

    public static final Coordinate validate(Coordinate coordinate) {

        Objects.requireNonNull(coordinate);
        coordinate.validate();
        return coordinate;
    }


    public String toSimpleString() {

        return "(" + x.toString() + "," + y.toString() + ")";
    }


    @Override
    public int compareTo(Coordinate o) {

        Coordinate.validate(o);
        int compX = x().compareTo(o.x());
        int compY = y().compareTo(o.y());

// Don't include corners of the rectangle
        if(compX < 1) {

            if(compY < 0)
                return compY;
            else if(compY < 1)
                return compY;
        }
        return 1;

    }

}

// OLD COMPARETO METHOD - x=-1 and y=0 RETURNED 0
//if(x.compareTo(o.x) < 1) {
//
//    if(y.compareTo(o.y) < 0)
//        return -1;
//    else if(y.compareTo(o.y) < 1)
//        return 0;
//}
//return 1;

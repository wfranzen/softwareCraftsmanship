package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class BiDimensionalMap<T> {

    private final SortedMap<BigDecimal, SortedMap<BigDecimal, Collection<T>>> points = new TreeMap<>();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    BiDimensionalMap(Collection<BigDecimal> xCoord, Collection<BigDecimal> yCoord) {

        Objects.requireNonNull(xCoord);
        Objects.requireNonNull(yCoord);

        Updater constructorUpdater = this.getUpdater();

        for (BigDecimal x : xCoord) {
            Objects.requireNonNull(x);
            for (BigDecimal y : yCoord) {

                Objects.requireNonNull(y);
                constructorUpdater.setCoordinate(new Coordinate(x, y));
                constructorUpdater.add(); // .add() will by default create empty hashSets and collections at each point in xCoord x yCoord
            }
        }
    }

    public final void addEverywhere(T value) {

        Objects.requireNonNull(value);
        Updater addEvery = this.getUpdater();
        addEvery.addValue(value);

        for (BigDecimal x : xSet()) {
            for (BigDecimal y : ySet(x)) {
                addEvery.setCoordinate(new Coordinate(x, y));
                addEvery.add();
            }
        }

    }

//    BiDimensionalMap() {
//
//    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public final Collection<T> get(BigDecimal x, BigDecimal y) {

        Objects.requireNonNull(x);
        Objects.requireNonNull(y);
// ASK QUESTION ABOUT THIS
        if (Objects.nonNull(points.get(x))) {

            return points.get(x).get(y);
        }

        return null;
    }

    public final Collection<T> get(Coordinate coordinate) {

        Coordinate.validate(coordinate);
        return get(coordinate.x(), coordinate.y());
    }

    public final Set<BigDecimal> xSet() {

        return points.keySet();
    }

    public final Set<BigDecimal> ySet(BigDecimal x) {

        Objects.requireNonNull(x);
        return points.getOrDefault(x, Collections.emptySortedMap()).keySet();
    }

    public final List<Coordinate> coordinateSet() {

        List<Coordinate> coordSet = new LinkedList<>();

        xSet().forEach(xCoord -> ySet(xCoord).stream().map(yCoord -> new Coordinate(xCoord, yCoord)).forEach(coordSet::add));
        return coordSet;
    }

    public final List<Collection<T>> collectionList() {

        return coordinateSet().stream()        // List<Coordinate> -> Stream<List<Coordinate>> ->
                .map(coords -> get(coords))  // Stream<Coordinate> -> Stream<InterestPoint> ->
                .collect(Collectors.toList()); // List<InterestPoint>

    }

    public final long collectionSize() {

        return collectionList().stream()
                .mapToLong(Collection::size)
                .sum();
    }

    public final long collectionSize(Predicate<? super T> filter) {

        Objects.requireNonNull(filter);

        return collectionList().stream()
                .flatMap(Collection::stream)
                .filter(filter)
                .count();
    }

    public final String toString() {

        StringBuilder mapRep = new StringBuilder();
        for (Coordinate coordString : coordinateSet()) {
                mapRep.append("Marker(s): ").append(get(coordString)).append(" at ").append(coordString).append("\n");
        }


        return mapRep.toString();
    }

    public final BiDimensionalMap<T> slice(Rectangle rectangle) { // HOW TO USE SUBMAP?

        Rectangle.validate(rectangle);

        BiDimensionalMap<T> rectBounds = new BiDimensionalMap<>(new HashSet<>(), new HashSet<>());
        Updater rectUpdater = rectBounds.getUpdater();

        for (Coordinate coordinate : coordinateSet()) {

            if (coordinate.compareTo(rectangle.bottomLeft()) < 0)
                continue;
            if (coordinate.compareTo(rectangle.topRight()) > -1)
                continue;
            rectUpdater.setCoordinate(coordinate);
            rectUpdater.setValues(get(coordinate));
            rectUpdater.add();
        }
        return rectBounds;

    }


    public final Updater getUpdater() {

        return new Updater();
    }

    public final class Updater {

        private BigDecimal x = new BigDecimal("0");
        private BigDecimal y = new BigDecimal("0");

        private Supplier<Collection<T>> collectionFactory = HashSet::new;
        private Collection<T> values = collectionFactory.get();

        //Setter methods for the four private instance variables declared above
        public final Updater setX(BigDecimal x) {

            this.x = x;
            return this;
        }

        public final Updater setY(BigDecimal y) {

            this.y = y;
            return this;
        }

        public final Updater setCollectionFactory(Supplier<Collection<T>> collectionFactory) {

            Objects.requireNonNull(collectionFactory);
            this.collectionFactory = collectionFactory;
            return this;
        }

        public final Updater setValues(Collection<T> values) {

            Objects.requireNonNull(values);
            this.values = values;
            return this;
        }

        public final Updater setCoordinate(Coordinate coordinate) {

            Coordinate.validate(coordinate);

            this.x = coordinate.x();
            this.y = coordinate.y();
            return this;
        }

        public final Updater addValue(T value) {

            Objects.requireNonNull(value);
            this.values.add(value);
            return this;
        }

        public final Collection<T> set() {

            this.checkIfXNull();
            // Sets the previously specified coordinates to the values collection
            // Additionally, returns the old values if any (or null)
            return points.get(x).put(y, this.values);
        }

        public final boolean add() {

            this.checkIfXNull();
            // Adds the values collection to the previously specified coordinates
            // If the values are modified points in the process, return true. Otherwise, return false
            if (points.get(x).get(y) == null) {
                points.get(x).put(y, collectionFactory.get());
            }
            return points.get(x).get(y).addAll(this.values);
        }


        // Additional helper and auxiliary methods

        // If the specified x in map is null, create a new tree map at that location
        // Otherwise, if the specified y in map is null, create a new collection
        void checkIfXNull() {

            points.computeIfAbsent(x, x -> new TreeMap<>());
        }
    } // End of Updater()


}
package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class RectilinearRegion {

    private final Set<Rectangle> rectangles;

    private RectilinearRegion(Set<Rectangle> rectangles) {

        Objects.requireNonNull(rectangles);

        this.rectangles = rectangles.stream()
                .map( rectangle -> Rectangle.validate(rectangle))
                .collect(Collectors.toSet());

    }

    public final Set<Rectangle> getRectangles() {

        return this.rectangles;
    }

    final BiDimensionalMap<Rectangle> rectangleMap() {

        /*
        * Calls on a helper method, passing in a function to be used in Rectangle.java to get a rectangle's X/Y bounds
        * Creates a set of all the values between the bounds left/bottom inclusive, right/top exclusive
        * All the separate rectangles bounds are then concatenated into what is xCoord and yCoord. Set deletes duplicates.
        * Allows for rectangles to be touching directly on any side or corner
        */

        BiDimensionalMap<Rectangle> grid = new BiDimensionalMap<>( getCoord(Rectangle::left, Rectangle::right), getCoord(Rectangle::bottom, Rectangle::top));
        BiDimensionalMap<Rectangle>.Updater gridUpdater = grid.getUpdater();

        for (Rectangle rect : getRectangles()) { //O( n^3 ) is absolute garbage

            BiDimensionalMap<Rectangle> tempGrid = grid.slice(rect);
            tempGrid.addEverywhere(rect);

            for(BigDecimal x : rect.rectBounds(rect.left(), rect.right())) {
                for(BigDecimal y : rect.rectBounds(rect.bottom(), rect.top())) {

                    gridUpdater.setCoordinate(new Coordinate(x, y));
                    gridUpdater.setValues( tempGrid.get(x,y));
                    gridUpdater.add();
                }
            }
        }
        return grid;
    }

    public boolean isOverlapping() {

        for(Coordinate coord : rectangleMap().coordinateSet()) {
            // Each coordinate in the newly created grid (from rectangleMap) should only have one rectangle
            if( rectangleMap().get(coord).size() > 1 ) {
                return true;
            }
        }
        return false;
    }

    public static final RectilinearRegion of(Set<Rectangle> rectangles) {

        // Null checks for rectangles object and all the rectangles within
        Objects.requireNonNull(rectangles);
        rectangles.forEach(rect -> Rectangle.validate(rect));

        // and not overlapping
        RectilinearRegion newRegion = new RectilinearRegion(rectangles);
        if ( newRegion.isOverlapping() )  {
            throw new IllegalStateException("The given rectilinear region is overlapping.");
        }

        return newRegion;
    }


    // Helper and Auxiliary Methods

    Set<BigDecimal> getCoord(Function<Rectangle, BigDecimal> lower, Function<Rectangle, BigDecimal>  upper) {

        Function<Rectangle, BigDecimal> left = Rectangle::left;

        return getRectangles().stream()
                .flatMap(rect -> rect.rectBounds(lower.apply(rect), upper.apply(rect)).stream())
                .collect(Collectors.toSet());
    }


}


// Separate xCoord and yCoord methods before turning into a single one
/*    Set<BigDecimal> getXCoord() {

        return getRectangles().stream()
                .flatMap(rect -> rect.rectBounds(rect.left(), rect.right()).stream())
                .collect(Collectors.toSet());
    }

    Set<BigDecimal> getYCoord() {

        return getRectangles().stream()
                .flatMap(rect -> rect.rectBounds(rect.bottom(), rect.top()).stream())
                .collect(Collectors.toSet());
    }*/

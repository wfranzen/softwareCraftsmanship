package edu.cwru.wcf13.gis;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.SortedSet;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public record Rectangle(Coordinate bottomLeft, Coordinate topRight) {


    public final Rectangle validate() {

        Coordinate.validate(bottomLeft());
        Coordinate.validate(topRight());

        // If 0 then the rectangle is a line as X. or Y.compareTo = 0, and if 1 then bottomLeft's X or Y is greater than topRight's
        if( bottomLeft().compareTo(topRight()) > -1)
            throw new IllegalStateException("The bottom left of the rectangle exceeds the bounds of the top right.");

        return this;
    }

    public static final Rectangle validate(Rectangle rectangle) {

        Objects.requireNonNull(rectangle);
        return rectangle.validate();
    }

    // Validate inside these?
    public final BigDecimal left() {

        return bottomLeft().x();
    }
    public final BigDecimal right() {

        return topRight().x();
    }
    public final BigDecimal bottom() {

        return bottomLeft().y();
    }
    public final BigDecimal top() {

        return topRight().y();
    }

    public final String toString() {
        // Returns the string: "The bottom left coordinate is (x1,y1), and the top right coordinate is (x2, y2)"
        return "RECTANGLE: "
                + bottomLeft().toSimpleString()
                + " to "
                + topRight().toSimpleString();
    }

    // Helper and Auxiliary Methods

    Set<BigDecimal> rectBounds(BigDecimal lower, BigDecimal upper) {

        Objects.requireNonNull(lower);
        Objects.requireNonNull(upper);

        return Stream.iterate(lower,
                        i -> i.compareTo(upper) < 0,
                        i -> i.add(BigDecimal.ONE))
                .collect(Collectors.toSet());

    }


    /* One line alternative with 0 complexity: Honestly a little jumbled up and hard to read.
    *
    *       return Stream.iterate(left(), i -> i.compareTo(right()) < 1, i -> i.add(BigDecimal.ONE))
    *       .collect(Collectors.toSet());
    *
     */
}
    /*final Set<BigDecimal> xBounds() {

        Set<BigDecimal> xValues = new HashSet<>();

        for (BigDecimal i = left(); i.compareTo(right()) < 1; i = i.add(BigDecimal.ONE)) {
            xValues.add(i);
        }
        return xValues;
    }

    Set<BigDecimal> yBounds() {

        Set<BigDecimal> yValues = new HashSet<>();

        for (BigDecimal i = bottom(); i.compareTo(top()) < 1; i = i.add(BigDecimal.ONE)) {
            yValues.add(i);
        }
        return yValues;
    }*/

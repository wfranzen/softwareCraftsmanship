package edu.cwru.wcf13.gis;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InterestPointTest {

    @Test
    void validate() {
    }

    @Test
    void testValidate() {
    }

    @Test
    void hasMarker() {
    }

    @Test
    void testToString() {
    }

    @Test
    void coordinate() {
    }

    @Test
    void marker() {
    }
}
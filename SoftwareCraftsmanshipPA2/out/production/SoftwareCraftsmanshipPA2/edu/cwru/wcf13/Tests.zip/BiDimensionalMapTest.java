package edu.cwru.wcf13.gis;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class BiDimensionalMapTest {

    BiDimensionalMap<BigDecimal> testMap = new BiDimensionalMap<>();

    @Test
    void get() {
    }

    @Test
    void testGet() {
    }

    @Test
    void getUpdater() {
    }
}
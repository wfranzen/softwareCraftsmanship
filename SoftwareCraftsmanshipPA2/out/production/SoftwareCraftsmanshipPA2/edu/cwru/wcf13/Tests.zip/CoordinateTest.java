package edu.cwru.wcf13.gis;

import org.junit.jupiter.api.DisplayName;

import java.math.BigDecimal;
import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.*;

class CoordinateTest {

    private final Coordinate nullCoordinate = new Coordinate(new BigDecimal("1.0"), new BigDecimal("1.0"));
    private final Coordinate nullCoordinateY = new Coordinate(new BigDecimal("1.0"), null);
    private final Coordinate nullCoordinateX = new Coordinate(null, new BigDecimal("1.0"));

    @org.junit.jupiter.api.Test
    @DisplayName("Validate x and y != null")
    void validate() {

        assertEquals(new Coordinate(new BigDecimal("1.0"), new BigDecimal("1.0")), nullCoordinate);
        assertEquals(null, nullCoordinateX);
        assertEquals(null, nullCoordinateY);
    }

    @org.junit.jupiter.api.Test
    void testValidate() {
    }

    @org.junit.jupiter.api.Test
    void toSimpleString() {
    }

    @org.junit.jupiter.api.Test
    void compareTo() {
    }

    @org.junit.jupiter.api.Test
    void x() {
        assertEquals(new BigDecimal("1.0"), nullCoordinate.x());
    }

    @org.junit.jupiter.api.Test
    void y() {
        assertEquals(new BigDecimal("1.0"), nullCoordinate.y());
    }
}